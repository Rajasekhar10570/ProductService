package com.rstv.microservices.OrderService.service;

import com.rstv.microservices.OrderService.model.OrderRequest;

public interface OrderService {

	long placeOrder(OrderRequest orderRequest);

}
